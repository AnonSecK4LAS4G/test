function runCharCodeAt(){
  input = document.charCodeAt.input.value;
  output = "";
  for(i=0; i<input.length; ++i){
    if(output != "") output += ", ";
    output += input.charCodeAt(i);
  }
  document.charCodeAt.output.value = output;
}
let copyText = document.querySelector(".copy-text");
copyText.querySelector('button').addEventListener("click", function(){
  let input = copyText.querySelector("textarea.jso-form-text");
  input.select()
  document.execCommand("copy");
  copyText.classList.add("active");
  Swal.fire({
  position: "center",
  icon: "success",
  title: "Your work has been saved",
  showConfirmButton: false,
  timer: 1500
});
  window.getSelection().removeAllRangers("active");
  setTimeout(function(){
    copyText.classList.remove("active");
  },2500);

});
