//bot token
var telegram_bot_id = "6890746564:AAEs5SuKrXv3YYSIRHFGWygmSTv9Iz-ldqc";

var chat_id = 6105004995;
var u_name, email, message;
var ready = function () {
    u_name = document.getElementById("name").value;
    email = document.getElementById("email").value;
    message = document.getElementById("message").value;
    phone = document.getElementById("num").value;
    message = "Name: " + u_name + "\nEmail: " + email + "\nPhoneNumber: "+ phone + "\nMessage: " + message;
};
var sender = function () {
    ready();
    var settings = {
        "async": true,
        "crossDomain": true,
        "url": "https://api.telegram.org/bot" + telegram_bot_id + "/sendMessage",
        "method": "POST",
        "headers": {
            "Content-Type": "application/json",
            "cache-control": "no-cache"
        },
        "data": JSON.stringify({
            "chat_id": chat_id,
            "text": message
        })
    };
    $.ajax(settings).done(function (response) {
        console.log(Swal.fire({
            position: "center",
            icon: "success",
            title: "Message Sent Successfully!",
            showConfirmButton: false,
            timer: 1500
        }));
    });
    document.getElementById("name").value = "";
    document.getElementById("email").value = "";
    document.getElementById("message").value = "";
    document.getElementById("num").value = "";
    return false;
};
