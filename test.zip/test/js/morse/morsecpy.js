function myFunction() {
      var copyText = document.getElementById("output");
    
      copyText.select();
      copyText.setSelectionRange(0, 99999);
    
      document.execCommand("copy");
    
      alert("Copt to Clipboard! : " + copyText.value);
    }
