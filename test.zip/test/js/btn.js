$(document).ready(function() {
  $('#icon').click(function(){
    $('.navul').toggleClass('react');
  });
});
